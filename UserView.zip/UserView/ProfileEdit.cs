﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Cloud.Firestore;

namespace UserView
{
    public partial class ProfileEdit : Form
    {
        private FirestoreDb db;

        public ProfileEdit()
        {
            InitializeComponent();
            createFirestoreCon();
            getUserAsync();
        }

        #region Database Section
        private void createFirestoreCon()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            db = FirestoreDb.Create("gray2green-24dc6");
        }

        private async void getUserAsync()
        {
            string[] s = new string[2];
            try
            {
                DocumentReference doc = db.Collection("User").Document("001");
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if (snap.Exists)
                {
                    UserData data = snap.ConvertTo<UserData>();
                    fname.Text = data.Fname;
                    lname.Text = data.Lname;
                    //nic.Text = data.NIC;
                    //g2g.Text = data.G2G;
                    email.Text = data.Email;
                    tele.Text = data.Tel;
                }
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }
        #endregion

        #region Reference Section
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
