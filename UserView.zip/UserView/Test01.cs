﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Cloud.Firestore;

namespace UserView
{
    public partial class Test01 : Form
    {
        Calculations cal = new Calculations();
        DatabaseClass db = new DatabaseClass();

        private int t = 0;
        private FirestoreDb db1;

        public Test01()
        {
            InitializeComponent();
            /*l.Text = cal.getTime();
            timer1.Start();
            check();*/
            //createFirestoreCon();
            //set1Async();
            //set1();
            db.setLogin();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            db.setLogout();
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            l.Text = cal.getTime();
        }

        private void check()
        {
            bool t = cal.IsConnectedToInternet();
            if(t == true)
            {
                l1.Text = "Has Internet Connection";
            }
            else if(t == false)
            {
                l1.Text = "No Internet Connection";
            }
        }

        private void set()
        {
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
                Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
                FirestoreDb fd = FirestoreDb.Create("gray2green-24dc6");
                l.Text = "success";
            }
            catch( Exception e)
            {
                string to = e.ToString();
                MessageBox.Show(to);
            }
        }
        
        async void set1Async()
        {
            string[] s = new string[2];
            try
            {
                DocumentReference doc = db1.Collection("user").Document("1");
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if (snap.Exists)
                {
                    data d = snap.ConvertTo<data>();
                    l.Text = d.age;
                    l1.Text = d.name;
                    MessageBox.Show("Successfull");
                }
                else
                {
                    MessageBox.Show("Unsuccessfull");
                }
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }
        
        private void set1()
        {
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory + @"test1-f3b61.json";
                Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
                FirestoreDb dg = FirestoreDb.Create("test1-f3b61");
                DocumentReference doc = dg.Collection("user").Document("2");
                Dictionary<string, object> data1 = new Dictionary<string, object>()
                {
                    { "name","yasas"},
                    { "age","12"}
                };
                doc.SetAsync(data1);
                MessageBox.Show("Successfull");
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }

        private void createFirestoreCon()
        {
            try
            {
                string path = AppDomain.CurrentDomain.BaseDirectory + @"iot-project-18f25.json";
                Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
                db1 = FirestoreDb.Create("iot-project-18f25");
                MessageBox.Show("Successfull");
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }


    }
}
