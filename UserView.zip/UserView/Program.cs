﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new LogIn());
            //Application.Run(new ResetPassword2());
            Application.Run(new Home());
            //Application.Run(new Register1());
            //Application.Run(new Test01());
            //Application.Run(new Profile());
            //Application.Run(new PlantBeds());
            //Application.Run(new Load());
        }
    }
}
