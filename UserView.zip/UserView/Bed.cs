﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class Bed : UserControl
    {
        private string _bed;
        private string _name;
        private string _date;

        public Bed(string b,string n,string d)
        {
            InitializeComponent();
            //load();
            name.Text = n;
            date.Text = d;
            num.Text = b;
        }

        //[Category("Custom Props")]
        //public string sdate
        //{
        //    get { return _date; }
        //    set { _date = value; }
        //}

        //[Category("Custom Props")]
        //public string plantname
        //{
        //    get { return _name; }
        //    set { _name = value; }
        //}

        //[Category("Custom Props")]
        //public string bed
        //{
        //    get { return _bed; }
        //    set { _bed = value; }
        //}

        private void load()
        {
            name.Text = _name;
            date.Text = _date;
            num.Text = _bed;
        }
    }
}
