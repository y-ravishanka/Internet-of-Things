﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserView
{
    class FormArrange
    {
        public static LogIn loginPage
        {
            get
            {
                if (lpage == null)
                {
                    lpage = new LogIn();
                }
                return lpage;
            }
        }
        private static LogIn lpage;

        public static ResetPassword2 resetpassword
        {
            get
            {
                if (reset == null)
                {
                    reset = new ResetPassword2();
                }
                return reset;
            }
        }
        private static ResetPassword2 reset;

        public static Register2 register
        {
            get
            {
                if (regi == null)
                {
                    regi = new Register2();
                }
                return regi;
            }
        }
        private static Register2 regi;

        public static ErrorConnection Error1
        {
            get
            {
                if (er1 == null)
                {
                    er1 = new ErrorConnection();
                }
                return er1;
            }
        }
        private static ErrorConnection er1;

        public static Load load
        {
            get
            {
                if (lad == null)
                {
                    lad = new Load();
                }
                return lad;
            }
        }
        private static Load lad;
    }
}
