﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class ResetPassword2 : Form
    {
        public ResetPassword2()
        {
            InitializeComponent();
        }

        #region Form Control Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        #region Form Customizing Section
        private void butEnter(Button but)
        {
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void butLeave(Button but)
        {
            but.BackColor = Color.FromArgb(14, 9, 36);
            but.ForeColor = Color.White;
        }
        #endregion

        #region References Section
        private void button3_MouseEnter(object sender, EventArgs e)
        {
            butEnter(button3);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            butLeave(button3);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            butEnter(button2);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            butLeave(button2);
        }
        #endregion


    }
}
