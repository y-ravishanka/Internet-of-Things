﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class PlantBeds : Form
    {
        Calculations cal = new Calculations();

        public PlantBeds()
        {
            InitializeComponent();
        }

        private void setBeds()
        {
            Bed[] beds = new Bed[4];

            for (int i = 0; i < beds.Length; i++)
            {
                beds[i] = new Bed((i+1).ToString(),"Karat",cal.getDate());
                beds[i].BackColor = Color.White;
                beds[i].Width = flow.Width;
                flow.Controls.Add(beds[i]);
            }
        }

        private void PlantBeds_Load(object sender, EventArgs e)
        {
            setBeds();
        }
    }
}
