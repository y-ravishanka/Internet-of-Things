﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FireSharp.Interfaces;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Exceptions;
using System.Windows.Forms;
using Google.Cloud.Firestore;
using System.Data.SqlClient;

namespace UserView
{
    class DatabaseClass
    {
        Calculations cal = new Calculations();

        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Shadow\Documents\IoT\UserView\UserView\Database.mdf;Integrated Security=True");
        private FirestoreDb db;

        public DatabaseClass()
        {
            createFirestoreCon();
        }

        private void createFirestoreCon()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            db = FirestoreDb.Create("gray2green-24dc6");
        }

        private IFirebaseConfig rcon = new FirebaseConfig()
        {
            AuthSecret = "D8HTybftVRWyAnf5JfYbsGmA7gsIlpok277UVUYb",
            BasePath = "https://gray2green-24dc6-default-rtdb.asia-southeast1.firebasedatabase.app/"
        };

        #region RealTime Database Section
        public string[] getRealData()
        {
            string[] s = new string[3];
            int t = 0;
            s[0] = t.ToString();
            try
            {
                IFirebaseClient client = new FireSharp.FirebaseClient(rcon);
                var result = client.Get("FirebaseIOT");
                RData data = result.ResultAs<RData>();
                s[1] = data.humidity;
                s[2] = data.temperature;
                t = 1;
            }
            catch(Exception e)
            {
                string tmp = e.ToString();
                MessageBox.Show(tmp);
                t = 0;
            }
            s[0] = t.ToString();
            return s;
        }
        #endregion

        #region SQL Database Section
        public bool systemUse()
        {
            int tmp = 0;
            bool t = false;
            string que = "select use from system_data where id = 1";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp = dr1.GetInt32(0);
                    }
                    if(tmp == 0)
                    { t = false; }
                    else if(tmp == 1)
                    { t = true; }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = false;
                string s = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
            return t;
        }

        public int setUserProfile(string fname,string lname,string nic, string g2g, string email, string tele)
        {
            int tmp = 0;
            string que = "insert into user_data (fname,lname,nic,email,tele,g2g) values('"+fname+ "','" + lname + "','" + nic + "','" + email + "','" + tele + "','" + g2g + "')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0;
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int updateuser(string fname, string lname, string pass, string email, string tele)
        {
            int tmp = 0;
            string que = "update user_data set fname = '" + fname + "',lname = '" + lname + "', password = '" + pass + "',email ='" + email + "',tele = '" + tele + "' where id = 1";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0;
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string[] getLogin()
        {
            string[] tmp = new string[2];
            bool t = false;
            string que = "select (nic,password) from user_data where id = 1";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[0] = dr1.GetString(0);
                        tmp[1] = dr1.GetString(1);
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = false;
                string s = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string getg2g()
        {
            string tmp = null;
            bool t = false;
            string que = "select top 1 g2g from user_data ";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp = dr1.GetString(0);
                    }
                }
                else
                {
                    tmp = "no";
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = false;
                string s = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public string[] getusername()
        {
            string[] tmp = new string[2];
            bool t = false;
            string que = "select fname,lname from user_data where id = 1";
            SqlCommand cmd1 = new SqlCommand(que, con);
            try
            {
                con.Open();
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.HasRows)
                {
                    while (dr1.Read())
                    {
                        tmp[0] = dr1.GetString(0);
                        tmp[1] = dr1.GetString(1);
                    }
                }
                dr1.Close();
            }
            catch (Exception e)
            {
                t = false;
                string s = Convert.ToString(e);
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setLogin()
        {
            int tmp = 0;
            string que = "insert into activity_log (date,login_time) values('" + cal.getDateOnly() + "','" + cal.getTime() + "')";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0; 
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }

        public int setLogout()
        {
            int tmp = 0;
            string que = "update activity_log set logout_time = '" + cal.getTime() + "' where id = (select top 1 id from activity_log order by id desc)";
            SqlCommand cmd = new SqlCommand(que, con);
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                tmp = 1;
            }
            catch (Exception e)
            {
                string s = Convert.ToString(e);
                tmp = 0;
            }
            finally
            {
                con.Close();
            }
            return tmp;
        }
        #endregion

        /*
        public void setUser()
        {
            try
            {
                DocumentReference doc = db.Collection("User").Document("Hello YR");
                Dictionary<string, object> data1 = new Dictionary<string, object>()
                {
                {"hello ","Good Morning" },
                {"status","connected to the database" }
                };
                doc.SetAsync(data1);
                MessageBox.Show("Successfull");
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }

        public async void getUserAsync()
        {
            string[] s = new string[2];
            try
            {
                DocumentReference doc = db.Collection("User").Document("000");
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if(snap.Exists)
                {
                    UserData data = snap.ConvertTo<UserData>();
                    s[1] = data.Fname;
                    s[2] = data.Lname;
                }
                MessageBox.Show("Successfull\n"+s[1]+"\n"+s[2]);
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }
        */
    }
}
