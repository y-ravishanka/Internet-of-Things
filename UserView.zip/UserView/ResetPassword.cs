﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class ResetPassword : Form
    {
        public ResetPassword()
        {
            InitializeComponent();
            clearFields();
        }

        #region Form Control Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        #region Input Customize Section
        private void enterUser()
        {
            if(txtEmail.Text == "User Name")
            {
                txtEmail.Text = "";
                txtEmail.ForeColor = Color.Black;
            }
            panelUser.BackColor = Color.White;
        }

        private void leaveUser()
        {
            if (txtEmail.Text == "")
            {
                txtEmail.Text = "User Name";
                txtEmail.ForeColor = Color.Gray;
            }
            panelUser.BackColor = Color.FromArgb(14, 9, 36);
        }

        private void enterCode()
        {
            if (txtCode.Text == "Verification Code")
            {
                txtCode.Text = "";
                txtCode.ForeColor = Color.Black;
            }
            panelPWord.BackColor = Color.White;
        }

        private void leaveCode()
        {
            if (txtCode.Text == "")
            {
                txtCode.Text = "Verification Code";
                txtCode.ForeColor = Color.Gray;
            }
            panelPWord.BackColor = Color.FromArgb(14, 9, 36);
        }

        private void txtEmail_MouseEnter(object sender, EventArgs e)
        {
            enterUser();
        }

        private void txtEmail_MouseLeave(object sender, EventArgs e)
        {
            leaveUser();
        }

        private void txtCode_MouseEnter(object sender, EventArgs e)
        {
            enterCode();
        }

        private void txtCode_MouseLeave(object sender, EventArgs e)
        {
            leaveCode();
        }
        #endregion

        #region Functions Section
        private void clear()
        {
            warning1.Text = null;
            warning2.Text = null;
        }

        private void clearFields()
        {
            clear();
            txtCode.Text = "Verification Code";
            txtEmail.Text = "Email Address";
            butSend.Text = "Send Code";
        }


        #endregion

        #region Reference Section
        private void button2_Click(object sender, EventArgs e)
        {
            clearFields();
            FormArrange.resetpassword.Show();
            this.Close();
        }

        #endregion

    }
}
