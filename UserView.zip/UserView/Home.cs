﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class Home : Form
    {
        Calculations cal = new Calculations();
        DatabaseClass db = new DatabaseClass();

        private int sec = 0;
        private Form activeForm = null;
        private float[,] count = new float[12, 2];
        private string[] counttime = new string[12];
        private int nav = 0;

        public Home()
        {
            InitializeComponent();
            submenuHide();
            timer1.Start();
            whenLoad();
            loaduser();
            colorbut(button4);
        }

        #region Form Control Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panelControl_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel7_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        #region Panel Control Section
        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void submenuHide()
        {
        }

        private void submenu(Panel p)
        {
            if(p.Visible == true)
            { p.Visible = false; }
            else if(p.Visible == false)
            {
                submenuHide();
                p.Visible = true; 
            }
        }
        #endregion

        #region Function Section
        
        private void whenLoad()
        {
            for(int i =0;i<12;i++)
            {
                count[i, 0] = 0;
                count[i, 1] = 0;
                counttime[i] = "";
            }
            day.Text = cal.getDate();
            getTempData();
        }

        private void loadchart()
        {
            chart1.Series.Clear();
            chart2.Series.Clear();
            chart1.Series.Add("Humidity");
            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series.Add("Temperature");
            chart2.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            for(int i = 0; i<12;i++)
            {
                chart1.Series["Humidity"].Points.AddXY(counttime[i], count[i,0]);
                chart2.Series["Temperature"].Points.AddXY(counttime[i], count[i, 1]);
            }
        }
        #endregion

        #region Database Section
        private void getTempData()
        {
            string[] s = db.getRealData();
            if (s[0] == "1")
            {
                hmid.Text = s[1];
                tmpt.Text = s[2];

                if(nav == 12)
                {
                    nav = 11;
                    for(int i = 0;i<11;i++)
                    {
                        count[i, 0] = count[i + 1, 0];
                        count[i, 1] = count[i + 1, 1];
                        counttime[i] = counttime[i + 1];
                    }
                }
                count[nav, 0] = float.Parse(s[1]);
                count[nav, 1] = float.Parse(s[2]);
                counttime[nav] = cal.getTime();
                nav++;
            }
            loadchart();
        }
        #endregion

        #region References Section
        private void button5_Click(object sender, EventArgs e)
        {
            openFroms(new PlantBeds());
            colorbut(button5);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            openFroms(new Profile());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            colorbut(button4);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormArrange.loginPage.Show();
            this.Close();
        }
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            time.Text = cal.getTime();
            if(sec%5 == 0)
            {
                getTempData();
            }
        }

        private void loaduser()
        {
            string[] un = db.getusername();
            fname.Text = un[0];
            lname.Text = un[1];
        }

        private void colorbut(Button but)
        {
            Button[] b = { button1, button4, button6, button5 };
            for(int  i = 0; i<b.Length;i++)
            {
                b[i].BackColor = Color.FromArgb(14, 9, 36);
                b[i].ForeColor = Color.White;
            }
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            colorbut(button6);
        }
    }
}
