﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Cloud.Firestore;

namespace UserView
{
    [FirestoreData]
    class UserData
    {
        [FirestoreProperty]
        public string Fname { get; set; }
        [FirestoreProperty]
        public string Lname { get; set; }
        [FirestoreProperty]
        public string NIC { get; set; }
        [FirestoreProperty]
        public string G2G { get; set; }
        [FirestoreProperty]
        public string Email { get; set; }
        [FirestoreProperty]
        public string Tel { get; set; }
        [FirestoreProperty]
        public string Password { get; set; }

    }
}
