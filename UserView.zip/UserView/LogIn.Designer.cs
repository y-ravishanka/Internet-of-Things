﻿
namespace UserView
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panelUser = new System.Windows.Forms.Panel();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.FPword = new System.Windows.Forms.Label();
            this.butLogin = new System.Windows.Forms.Button();
            this.warning2 = new System.Windows.Forms.Label();
            this.warning1 = new System.Windows.Forms.Label();
            this.panelPWord = new System.Windows.Forms.Panel();
            this.txtPWord = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.website = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panelUser.SuspendLayout();
            this.panelPWord.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(481, 35);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(446, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 35);
            this.button1.TabIndex = 0;
            this.button1.Text = "O";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseEnter += new System.EventHandler(this.button1_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.button1_MouseLeave);
            // 
            // panelUser
            // 
            this.panelUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.panelUser.Controls.Add(this.txtUser);
            this.panelUser.Location = new System.Drawing.Point(104, 241);
            this.panelUser.Name = "panelUser";
            this.panelUser.Size = new System.Drawing.Size(287, 37);
            this.panelUser.TabIndex = 1;
            // 
            // txtUser
            // 
            this.txtUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtUser.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.ForeColor = System.Drawing.Color.Gray;
            this.txtUser.Location = new System.Drawing.Point(0, 0);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(287, 32);
            this.txtUser.TabIndex = 0;
            this.txtUser.Text = "User Name";
            this.txtUser.Enter += new System.EventHandler(this.txtUser_Enter);
            this.txtUser.Leave += new System.EventHandler(this.txtUser_Leave);
            // 
            // FPword
            // 
            this.FPword.AutoSize = true;
            this.FPword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FPword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.FPword.Location = new System.Drawing.Point(230, 398);
            this.FPword.Name = "FPword";
            this.FPword.Size = new System.Drawing.Size(161, 21);
            this.FPword.TabIndex = 4;
            this.FPword.Text = "Forgotten Password";
            this.FPword.Click += new System.EventHandler(this.FPword_Click);
            // 
            // butLogin
            // 
            this.butLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.butLogin.FlatAppearance.BorderSize = 0;
            this.butLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butLogin.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butLogin.ForeColor = System.Drawing.Color.White;
            this.butLogin.Location = new System.Drawing.Point(104, 388);
            this.butLogin.Name = "butLogin";
            this.butLogin.Size = new System.Drawing.Size(112, 38);
            this.butLogin.TabIndex = 3;
            this.butLogin.Text = "LogIn";
            this.butLogin.UseVisualStyleBackColor = false;
            this.butLogin.Click += new System.EventHandler(this.butLogin_Click);
            this.butLogin.MouseEnter += new System.EventHandler(this.butLogin_MouseEnter);
            this.butLogin.MouseLeave += new System.EventHandler(this.butLogin_MouseLeave);
            // 
            // warning2
            // 
            this.warning2.BackColor = System.Drawing.Color.Transparent;
            this.warning2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.warning2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning2.ForeColor = System.Drawing.Color.Red;
            this.warning2.Location = new System.Drawing.Point(104, 349);
            this.warning2.Name = "warning2";
            this.warning2.Size = new System.Drawing.Size(287, 25);
            this.warning2.TabIndex = 2;
            this.warning2.Text = "* warning";
            // 
            // warning1
            // 
            this.warning1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning1.ForeColor = System.Drawing.Color.Red;
            this.warning1.Location = new System.Drawing.Point(104, 281);
            this.warning1.Name = "warning1";
            this.warning1.Size = new System.Drawing.Size(287, 25);
            this.warning1.TabIndex = 2;
            this.warning1.Text = "* warning";
            // 
            // panelPWord
            // 
            this.panelPWord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.panelPWord.Controls.Add(this.txtPWord);
            this.panelPWord.Location = new System.Drawing.Point(104, 309);
            this.panelPWord.Name = "panelPWord";
            this.panelPWord.Size = new System.Drawing.Size(287, 37);
            this.panelPWord.TabIndex = 1;
            // 
            // txtPWord
            // 
            this.txtPWord.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtPWord.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPWord.ForeColor = System.Drawing.Color.Gray;
            this.txtPWord.Location = new System.Drawing.Point(0, 0);
            this.txtPWord.Name = "txtPWord";
            this.txtPWord.Size = new System.Drawing.Size(287, 32);
            this.txtPWord.TabIndex = 0;
            this.txtPWord.Text = "Password";
            this.txtPWord.Enter += new System.EventHandler(this.txtPWord_Enter);
            this.txtPWord.Leave += new System.EventHandler(this.txtPWord_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 499);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(481, 35);
            this.panel2.TabIndex = 4;
            // 
            // website
            // 
            this.website.AutoSize = true;
            this.website.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.website.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(9)))), ((int)(((byte)(36)))));
            this.website.Location = new System.Drawing.Point(100, 438);
            this.website.Name = "website";
            this.website.Size = new System.Drawing.Size(195, 21);
            this.website.TabIndex = 4;
            this.website.Text = "To Grey to Green Website";
            this.website.Click += new System.EventHandler(this.website_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UserView.Properties.Resources.logo_new;
            this.pictureBox1.Location = new System.Drawing.Point(0, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(481, 151);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(481, 534);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.website);
            this.Controls.Add(this.FPword);
            this.Controls.Add(this.butLogin);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.warning2);
            this.Controls.Add(this.warning1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelPWord);
            this.Controls.Add(this.panelUser);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximumSize = new System.Drawing.Size(481, 534);
            this.MinimumSize = new System.Drawing.Size(481, 534);
            this.Name = "LogIn";
            this.Opacity = 0.95D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panelUser.ResumeLayout(false);
            this.panelUser.PerformLayout();
            this.panelPWord.ResumeLayout(false);
            this.panelPWord.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label warning2;
        private System.Windows.Forms.Label warning1;
        private System.Windows.Forms.Panel panelPWord;
        private System.Windows.Forms.TextBox txtPWord;
        private System.Windows.Forms.Panel panelUser;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button butLogin;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label FPword;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label website;
    }
}

