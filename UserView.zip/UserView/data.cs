﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Cloud.Firestore;

namespace UserView
{
    [FirestoreData]
    class data
    {
        [FirestoreProperty]
        public string age { get; set; }

        [FirestoreProperty]
        public string name { get; set; }
    }
}
