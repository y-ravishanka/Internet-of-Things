﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Cloud.Firestore;

namespace UserView
{
    public partial class Register2 : Form
    {
        DatabaseClass sql = new DatabaseClass();
        private FirestoreDb db;
        

        public Register2()
        {
            InitializeComponent();
            createFirestoreCon();
            clear();
        }

        private void clear()
        {
            warning.Text = null;
        }

        private bool check()
        {
            bool t = false;
            if(fname.Text == "" || fname.Text == null)
            {
                warningtxt();
            }
            else if (lname.Text == "" || lname.Text == null)
            {
                warningtxt();
            }
            else if (email.Text == "" || email.Text == null)
            {
                warningtxt();
            }
            else if (tele.Text == "" || tele.Text == null)
            {
                warningtxt();
            }
            else if (nic.Text == "" || nic.Text == null)
            {
                warningtxt();
            }
            else if (g2g.Text == "" || g2g.Text == null)
            {
                warningtxt();
            }
            else
            {
                t = true;
            }
            return t;
        }

        private void warningtxt()
        {
            warning.Text = "* please fill all the fields";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormArrange.loginPage.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(check() == true)
            {
                getUser();
            }
        }

        private void createFirestoreCon()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            db = FirestoreDb.Create("gray2green-24dc6");
        }

        public async void getUser()
        {
            string s = null;
            try
            {
                DocumentReference doc = db.Collection("User").Document(g2g.Text);
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if (snap.Exists)
                {
                    UserData data = snap.ConvertTo<UserData>();
                    s = data.NIC;
                }
                if (s == nic.Text)
                {
                    updateAsync();
                    _ = sql.setUserProfile(fname.Text, lname.Text, nic.Text, g2g.Text, email.Text, tele.Text);
                }
                else
                {
                    warning.Text = "* G2G code and NIC doesn't match";
                }
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
            
        }

        private async void updateAsync()
        {
            try
            {
                DocumentReference doc = db.Collection("User").Document(g2g.Text);
                Dictionary<string, object> data = new Dictionary<string, object>()
                {
                    {"Fname", fname.Text },
                    {"Lname",lname.Text },
                    {"NIC", nic.Text },
                    {"G2G",g2g.Text },
                    {"Email",email.Text },
                    {"Tel",tele.Text }
                };
                DocumentSnapshot snapshot = await doc.GetSnapshotAsync();
                if(snapshot.Exists)
                {
                    await doc.SetAsync(data);
                }
            }
            catch(Exception e)
            {
                string tmp = e.ToString();
                MessageBox.Show(tmp);
            }
        }
    }
}
