﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Cloud.Firestore;
using System.Data.SqlClient;

namespace UserView
{
    public partial class Profile : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Shadow\Documents\IoT\UserView\UserView\Database.mdf;Integrated Security=True");
        private FirestoreDb db;

        public Profile()
        {
            InitializeComponent();
            createFirestoreCon();
            getUserAsync();
            loadData();
        }

        #region Panel Section
        private Form activeForm = null;

        private void openFroms(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close(); // clear-up the varible to store childForm
            }
            activeForm = childForm; // save childForm in activeForm varible
            childForm.TopLevel = false; // stop childForm from behaving like a controler
            childForm.FormBorderStyle = FormBorderStyle.None; // remove childForm borders
            childForm.Dock = DockStyle.Fill; // make childForm fill the entire space
            
            panelBase.Controls.Add(childForm);
            panelBase.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        #endregion

        #region Function Section
        private void enterBut(Button but)
        {
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void leaveBut(Button but)
        {
            but.BackColor = Color.FromArgb(14, 9, 36);
            but.ForeColor = Color.White;
        }
        #endregion

        #region Database Section
        private void createFirestoreCon()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            db = FirestoreDb.Create("gray2green-24dc6");
        }

        public async void getUserAsync()
        {
            try
            {
                DocumentReference doc = db.Collection("User").Document("001");
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if (snap.Exists)
                {
                    UserData data = snap.ConvertTo<UserData>();
                    fname.Text = data.Fname;
                    lname.Text = data.Lname;
                    nic.Text = data.NIC;
                    g2g.Text = data.G2G;
                    email.Text = data.Email;
                    tele.Text = data.Tel;
                }
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }

        private void loadData()
        {
            string table = "activity_log";
            string que = "select top 20 * from activity_log order by Id desc";

            try
            {
                SqlDataAdapter dta = new SqlDataAdapter(que, con);
                DataSet ds = new DataSet();
                dta.Fill(ds, table);
                dataView.DataSource = ds;
                dataView.DataMember = table;
                table = null;
            }
            catch (Exception e)
            {
                string s1 = Convert.ToString(e);
                MessageBox.Show(s1);
            }
            finally
            {
                con.Close();
            }

        }
        #endregion

        #region Reference Section
        private void button3_Click_1(object sender, EventArgs e)
        {
            openFroms(new ProfileEdit());
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }
        #endregion

    }
}
