﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Cloud.Firestore;

namespace UserView
{
    public partial class Load : Form
    {
        DatabaseClass sql = new DatabaseClass();
        Calculations cal = new Calculations();

        private int startpoint = 0;
        private FirestoreDb db;
        public Load()
        {
            InitializeComponent();
            check();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            startpoint += 1;
            bunifuProgressBar1.Value = startpoint;
            if (bunifuProgressBar1.Value == 100)
            {
                bunifuProgressBar1.Value = 0;
                timer1.Stop();
                this.Hide();
                FormArrange.loginPage.Show();
            }
        }

        private void check()
        {
            bool t = cal.IsConnectedToInternet();
            if(t == true)
            {
                timer1.Start();
                createFirestoreCon();
                bool tmp = sql.systemUse();
                if (tmp == true)
                {
                    loaddata();
                }
            }
            else if(t == false)
            {
                FormArrange.Error1.Show();
                this.Close();
            }
        }

        private async void loaddata()
        {
            try
            {
                DocumentReference doc = db.Collection("User").Document(sql.getg2g());
                DocumentSnapshot snap = await doc.GetSnapshotAsync();
                if (snap.Exists)
                {
                    UserData data = snap.ConvertTo<UserData>();
                    _ = sql.updateuser(data.Fname, data.Lname, data.Password, data.Email, data.Tel);
                }
            }
            catch (Exception e)
            {
                string tm = e.ToString();
                MessageBox.Show(tm);
            }
        }

        private void createFirestoreCon()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"gray2green.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", path);
            db = FirestoreDb.Create("gray2green-24dc6");
        }
    }
}
