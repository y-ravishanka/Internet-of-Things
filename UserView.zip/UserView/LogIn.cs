﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserView
{
    public partial class LogIn : Form
    {
        DatabaseClass sql = new DatabaseClass();

        private bool tmp;
        
        public LogIn()
        {
            InitializeComponent();
            clearFields();
            tmp = sql.systemUse();
        }

        #region Form Control Section
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        #region Customize Input Fields Section
        private void enterUser()
        {
            panelUser.BackColor = Color.White;
            if (txtUser.Text == "User Name")
            {
                txtUser.Text = "";
                txtUser.ForeColor = Color.Black;
            }
        }

        private void leaveUser()
        {
            panelUser.BackColor = Color.FromArgb(14, 9, 36);
            if (txtUser.Text == "")
            {
                txtUser.Text = "User Name";
                txtUser.ForeColor = Color.Gray;
            }
        }

        private void enterPWord()
        {
            panelPWord.BackColor = Color.White;
            if (txtPWord.Text == "Password")
            {
                txtPWord.Text = "";
                txtPWord.ForeColor = Color.Black;
                txtPWord.PasswordChar = 'O';
            }
        }

        private void leavePWord()
        {
            panelPWord.BackColor = Color.FromArgb(14, 9, 36);
            if (txtPWord.Text == "")
            {
                txtPWord.Text = "Password";
                txtPWord.ForeColor = Color.Gray;
                txtPWord.PasswordChar = '\0';
            }
        }

        private void enterBut(Button but)
        {
            but.BackColor = Color.White;
            but.ForeColor = Color.Black;
        }

        private void leaveBut(Button but)
        {
            but.BackColor = Color.FromArgb(14, 9, 36);
            but.ForeColor = Color.White;
        }
        #endregion

        #region Function Section
        private void customForm()
        {
        }

        private void clear()
        {
            warning1.Text = null;
            warning2.Text = null;
        }

        private void clearFields()
        {
            clear();
            txtUser.Text = "User Name";
            txtPWord.Text = "Password";
        }
        #endregion

        #region References Section 
        private void txtUser_Enter(object sender, EventArgs e)
        {
            enterUser();
        }

        private void txtUser_Leave(object sender, EventArgs e)
        {
            leaveUser();
        }

        private void txtPWord_Enter(object sender, EventArgs e)
        {
            enterPWord();
        }

        private void txtPWord_Leave(object sender, EventArgs e)
        {
            leavePWord();
        }

        private void butLogin_MouseEnter(object sender, EventArgs e)
        {
            enterBut(butLogin);
        }

        private void butLogin_MouseLeave(object sender, EventArgs e)
        {
            leaveBut(butLogin);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            enterBut(button1);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            leaveBut(button1);
        }

        private void website_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.google.com/");
        }

        private void FPword_Click(object sender, EventArgs e)
        {
            if (tmp == true)
            {
                ResetPassword reset = new ResetPassword();
                reset.Show();
            }
            else if(tmp == false)
            {
                Register1 regis = new Register1();
                regis.Show();
            }
            clearFields();
            this.Hide();
        }
        #endregion

        #region Nothing
        #endregion

        private void butLogin_Click(object sender, EventArgs e)
        {
            if (tmp == true)
            {
                login();
            }
            else if (tmp == false)
            {
                Register1 regis = new Register1();
                regis.Show();
            }
            clearFields();
            this.Hide();
        }

        private void login()
        {
            string[] lg = sql.getLogin();
            if(lg[0] != txtUser.Text)
            {
                warning1.Text = "* Ivalid UserName";
            }
            else if(lg[1] != txtPWord.Text)
            {
                warning2.Text = "* Ivalid Password";
            }
            else
            {
                Home h = new Home();
                h.Show();
                this.Hide();
            }
        }
    }
}
