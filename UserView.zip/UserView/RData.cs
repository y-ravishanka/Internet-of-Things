﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserView
{
    class RData
    {
        public string humidity { get; set; }
        public string temperature { get; set; }
    }
}
